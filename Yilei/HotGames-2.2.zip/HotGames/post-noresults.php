<div class="post">
        
    <div class="entry">
        <p><?php _e('No results were found for your request!','themater'); ?></p>
    </div>

    <div id="content-search">
        <?php get_search_form(); ?>
    </div>
    
</div>