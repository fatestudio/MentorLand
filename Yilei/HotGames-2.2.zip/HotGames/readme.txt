HotGames theme by FThemes, http://fthemes.com
Online Demo: http://fthemes.com/demo/HotGames/
Theme URI: http://fthemes.com/hotgames-free-wordpress-theme/